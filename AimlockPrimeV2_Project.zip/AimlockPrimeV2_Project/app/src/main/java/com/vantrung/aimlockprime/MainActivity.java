package com.vantrung.aimlockprime;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private LinearLayout page;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("aimlock_prime_settings", MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 32, 28, 32);
        page.setBackgroundColor(Color.rgb(18,18,22));
        scroll.addView(page);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("AIMLOCK PRIME V2");
        title.setTextColor(Color.rgb(255,70,70));
        title.setTextSize(27);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 12, 0, 8);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("TRỢ LÝ CÀI ĐẶT ĐỘ NHẠY • FREE FIRE THƯỜNG");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, 24);
        page.addView(subtitle);

        addSlider("Nhìn xung quanh", "general", 0, 200, 100);
        addSlider("Red Dot", "red_dot", 0, 200, 95);
        addSlider("Ống ngắm 2X", "scope_2x", 0, 200, 90);
        addSlider("Ống ngắm 4X", "scope_4x", 0, 200, 85);
        addSlider("Ống ngắm súng ngắm", "sniper", 0, 200, 50);
        addSlider("Nhìn tự do", "free_look", 0, 200, 100);

        Button reset = new Button(this);
        reset.setText("ĐẶT LẠI MẶC ĐỊNH");
        reset.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            recreate();
        });
        page.addView(reset);

        TextView note = new TextView(this);
        note.setText("\nLưu ý: Đây là ứng dụng lưu gợi ý độ nhạy và thiết lập cá nhân. Ứng dụng không đọc, sửa bộ nhớ game, không tự ngắm và không tự ghim mục tiêu. Hãy thử điều chỉnh trong phần Cài đặt của trò chơi.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(13);
        note.setPadding(4, 18, 4, 8);
        page.addView(note);
    }

    private void addSlider(String label, String key, int min, int max, int fallback) {
        TextView heading = new TextView(this);
        heading.setText(label + ": " + prefs.getInt(key, fallback));
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(16);
        heading.setPadding(0, 14, 0, 0);
        page.addView(heading);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(prefs.getInt(key, fallback) - min);
        page.addView(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int value, boolean user) {
                heading.setText(label + ": " + (value + min));
                if (user) prefs.edit().putInt(key, value + min).apply();
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
    }
}
